import time
from SCRAPPER_WEB_RESULTS import EmailExtractor

def get_contact_details(url):
    then = time.time()
    if url[0:4] != 'http':
        url = 'http://' + url
    email_extractor = EmailExtractor()
    result_data = email_extractor.get_email(url)
    if result_data==None:return None
    emails = result_data['emails']
    if emails!=None and len(emails)>=1:emails = list(set(emails))

    print("website: ", url)

    if emails:
        print(emails)
    else:
        print("No email addresses found on the website.")

    email_extractor.driver.quit()
    now = time.time()
    print("Time Taken : ", now-then)

    return result_data


url = "https://www.vistatreeserviceinc.com/"
data = get_contact_details(url= url)

print(data)