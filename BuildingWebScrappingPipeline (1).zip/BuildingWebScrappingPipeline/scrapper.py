import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
import re
import requests
from urllib.parse import urlsplit, parse_qs
from urllib.parse import urlparse
import time
from tqdm import tqdm

def GetQueryString(query: dict):
    if 'current' not in query.keys():
        return ''
    if 'city' in query.keys() and 'state' in query.keys():
        url = f"https://www.google.com/search?q=tree+services+in+{query['city']}+ +{query['state']}&start={query['current']}"
    elif 'city' in query.keys():
        url = f"https://www.google.com/search?q=tree+services+in+{query['city']}+&start={query['current']}"
    elif 'state' in query.keys():
        url = f"https://www.google.com/search?q=tree+services+in+{query['state']}&start={query['current']}"
    else:
        return ''
    return url


def extractDomainURL(url):
    # Use urlsplit to split the URL into its components
    parsed_url = urlsplit(url)

    # Check if the 'q' parameter exists in the query string
    query_parameters = parse_qs(parsed_url.query)
    if 'q' in query_parameters:
        return query_parameters['q'][0]

    return None


def extractBaseURL(url):
    parsed_url = urlparse(url)
    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
    return base_url


def GetDomainList(url: str):
    # Define your User-Agent
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.89 Safari/537.36"

    # Create headers with the User-Agent
    headers = {'User-Agent': user_agent}
    response = requests.get(url)
    print("Status Code : ", response.status_code)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        links = soup.find_all("a")
        links_list = []
        for link in links:
            link_test = link['href']
            if link_test.startswith('/url?q=') and ('support.google.com' not in link_test) and (
                    'accounts.google.com' not in link_test) and ('q=/search' not in link_test):
                link_test = extractDomainURL(link_test)
                if link_test != None: links_list.append(extractBaseURL(link_test))
        return links_list
    return None


def BusinessDomainFetch(query: dict):
    current = 0
    domainList = []
    while True:
        query['current'] = current
        url = GetQueryString(query)
        print(url)
        if url == '':
            break
        total_wait_time = 8  # Total waiting time in seconds

        # Create a tqdm progress bar with the specified total time
        for remaining_time in tqdm(range(total_wait_time), desc="Waiting", unit="s"):
            time.sleep(1)  # Wait for 1 second

        currentPageDomain = GetDomainList(url)
        if currentPageDomain == None:
            print('Issue with status code.')
            break
        elif currentPageDomain == []:
            print('Scrapping ends here.')
            break
        print('Processed current : ', current)
        current += 10
        query['current'] = current
        domainList += currentPageDomain

    return domainList