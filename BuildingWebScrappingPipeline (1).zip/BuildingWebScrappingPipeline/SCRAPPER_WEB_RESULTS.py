import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from fuzzywuzzy import fuzz
from textdistance import jaccard
import tldextract
from bs4 import BeautifulSoup

class EmailExtractor:
    def __init__(self, driver_path=None):
        self.chrome_options = webdriver.ChromeOptions()
        self.chrome_options.add_argument('--headless')
        self.chrome_options.add_argument('--disable-gpu')
        self.website_title = None

        if driver_path:
            self.driver = webdriver.Chrome(executable_path=driver_path, options=self.chrome_options)
        else:
            self.driver = webdriver.Chrome(options=self.chrome_options)

    def extract_phone_numbers_from_page_source(self, page_source):
        # Create a BeautifulSoup object
        soup = BeautifulSoup(page_source, 'html.parser')

        # Find all links with href attributes starting with "tel:"
        tel_links = soup.find_all('a', href=re.compile(r'^tel:'))

        # Extract and collect the phone numbers from the links
        phone_numbers = []
        for link in tel_links:
            phone_number = link['href'][4:]  # Remove "tel:" prefix
            phone_numbers.append(phone_number)

        return phone_numbers

    def sort_email_addresses(self, emails, company_name):
        def custom_sort_key(email):
            return (company_name not in email, email)

        sorted_email_addresses = sorted(emails, key=custom_sort_key)
        return sorted_email_addresses

    def get_email_from_link(self, link):
        try:
            self.driver.get(link)
            self.driver.implicitly_wait(10)
            page_source = self.driver.page_source

            if self.website_title == None:
                try:
                    self.website_title = self.driver.title
                except:
                    pass

            # Define a regular expression pattern to match email addresses
            email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b'

            # Find all email addresses in the page source using the pattern
            email_addresses = re.findall(email_pattern, page_source)

            # Define a regular expression pattern to match phone numbers
            phone_pattern = r'\+?\d{1,4}[-\s]?\(?\d{1,4}\)?[-\s]?\d{1,12}'

            # Find all phone numbers in the text using the pattern
            phone_numbers = self.extract_phone_numbers_from_page_source(page_source)

            return email_addresses, phone_numbers
        except:
            return None

    def get_email(self, website):
        links = self.get_nav_links(website=website)
        emails = []
        phones = []
        # Extract emails from the base website as well
        temp_data = self.get_email_from_link(link=website)
        if temp_data!=None and len(temp_data)==2:
            email_addresses, phone_numbers = temp_data
            emails.append(email_addresses)
            phones.append(phone_numbers)
        for link in links:
            temp_data = self.get_email_from_link(link=link)
            if temp_data != None and len(temp_data) == 2:
                email_addresses, phone_numbers = temp_data
                emails.append(email_addresses)
                phones.append(phone_numbers)





        if len(phones)>=1:
            phones = list(set(phones[0]))
        else:
            phones = []

        print(phones, type(phones))

        if emails or phones:
            best_match = self.find_best_matching_email(emails, website)
            if best_match == None: return None
            company_name = self.preprocess_text2(text=website)
            best_match = list(set(best_match))

            # sorted_email_addresses = sorted(
            #     best_match,
            #     key=lambda email: (company_name not in email, email)
            # )

            emails = self.sort_email_addresses(emails=best_match, company_name=company_name)

            dict = {
                'business': self.website_title,
                'phones': phones,
                'emails': emails,
            }
            return dict
        else:
            return None

    def get_nav_links(self, website):
        try:
            self.driver.get(website)
            self.driver.implicitly_wait(10)

            nav_element = self.driver.find_element(By.TAG_NAME, 'nav')
            link_tags = nav_element.find_elements(By.TAG_NAME, 'a')
        except:
            return []

        links = []

        for link in link_tags:
            links.append(link.get_attribute('href'))

        links = list(set(links))

        fresh_links = []
        website_domain = self.preprocess_text2(text=website)
        if links:
            for link in links:
                if link and website_domain in link and 'contact' in link.lower():
                    fresh_links.append(link)

        return fresh_links

    @staticmethod
    def preprocess_text(text):
        text = re.sub(r"https?://|www\.|/", '', text)
        return text

    @staticmethod
    def preprocess_text2(text):
        domain_info = tldextract.extract(text)
        domain = domain_info.domain
        if domain_info.subdomain and domain_info.subdomain.lower() == 'www':
            domain = domain_info.domain

        return domain

    def find_best_matching_email(self, emails, website):
        company_domain = self.preprocess_text(website)
        best_match = None
        best_score = 0

        for email in emails:
            if not email:
                continue
            email_address = self.preprocess_text(email[0])
            score = self.calculate_fuzzy_score(email_address, company_domain)
            if score > best_score:
                best_match = email
                best_score = score

        if best_match:
            return best_match
        else:
            return None

    @staticmethod
    def calculate_fuzzy_score(email, company_name):
        return fuzz.token_sort_ratio(email, company_name)  # You can use your preferred scoring method here
