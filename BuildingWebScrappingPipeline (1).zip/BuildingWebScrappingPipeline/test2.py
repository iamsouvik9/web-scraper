from scrapper import BusinessDomainFetch

q = {
    'city': 'Needles',
    'state': 'Callifornia'
}

domainList = BusinessDomainFetch(q)

print(domainList)